var n=(...e)=>e.filter(Boolean).join(" ");export{n as a};
//# sourceMappingURL=chunk-O5KNUFBN.js.map
